// 创建者：mike
// Render only Mermaid fenced blocks; keep source visible when a diagram fails.
(function () {
  'use strict';
  const theme = window.markdownEditorMermaidTheme || 'default';
  let activeExpandedDiagram = null;
  const style = document.createElement('style');
  style.textContent = `
    :root{--md-panel:${theme === 'dark' ? '#161b22' : '#ffffff'};--md-ink:${theme === 'dark' ? '#e6edf3' : '#24292f'};--md-accent:${theme === 'dark' ? '#79c0ff' : '#0f62be'}}
    .md-mermaid{margin:16px 0;border:1px solid #8885;border-radius:8px;overflow:hidden}
    .md-mermaid-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:6px;padding:8px;background:var(--md-panel);color:var(--md-ink);border-bottom:1px solid #8884;font:13px/1.4 -apple-system,BlinkMacSystemFont,sans-serif}
    .md-mermaid button,.md-toc button{font:inherit;color:var(--md-ink);background:var(--md-panel);border:1px solid #8886;border-radius:5px;padding:5px 9px;cursor:pointer;min-height:30px}
    .md-mermaid button:hover,.md-toc button:hover{border-color:var(--md-accent)}
    .md-mermaid button:focus-visible,.md-toc button:focus-visible,.md-toc a:focus-visible,.md-mermaid-viewport:focus-visible{outline:2px solid var(--md-accent);outline-offset:2px}
    .md-mermaid-toolbar output{min-width:44px;text-align:center;font-variant-numeric:tabular-nums}
    .md-mermaid-hint{margin-left:auto;font-size:12px;opacity:.75}
    .md-mermaid-viewport{overflow:auto;cursor:grab;min-height:120px;max-height:640px;position:relative}
    .md-mermaid-viewport.md-dragging{cursor:grabbing;user-select:none}
    .md-mermaid-stage{padding:16px;box-sizing:content-box}
    .md-mermaid svg{display:block;max-width:none!important}
    html.md-diagram-expanded,html.md-diagram-expanded body{overflow:hidden!important}
    .md-mermaid-expanded{position:fixed;inset:0;z-index:2000;display:flex;flex-direction:column;margin:0;border:0;border-radius:0;background:var(--md-panel);width:auto;height:auto}
    .md-mermaid-expanded .md-mermaid-toolbar{flex-shrink:0}
    .md-mermaid-expanded .md-mermaid-viewport{flex:1;min-height:0;max-height:none}
    .md-mermaid-error{color:inherit;border-left:3px solid #da1e28;padding:8px 12px;margin:8px 0}
    .md-toc{position:fixed;top:12px;right:12px;z-index:1000;width:260px;max-width:calc(100vw - 24px);box-sizing:border-box;background:var(--md-panel);color:var(--md-ink);border:1px solid #8885;border-radius:9px;box-shadow:0 5px 20px #0002;font:13px/1.5 -apple-system,BlinkMacSystemFont,sans-serif}
    .md-toc.compact{width:auto}
    .md-toc-header{display:flex;gap:6px;padding:8px;align-items:center}
    .md-toc-toggle{flex:1;text-align:left;font-weight:600!important;white-space:nowrap}
    .md-toc-list{list-style:none!important;margin:0!important;padding:4px 8px 10px!important;max-height:55vh;overflow:auto}
    .md-toc-list li{list-style:none!important;margin:0!important;padding:0!important}
    .md-toc-list a{display:block;padding:6px 8px;border-radius:4px;color:var(--md-ink);text-decoration:none;overflow-wrap:anywhere;border-left:2px solid transparent}
    .md-toc-list a:hover,.md-toc-list a.is-current{color:var(--md-accent);background:#8882;border-left-color:var(--md-accent)}
    .md-toc [hidden]{display:none!important}
    .md-toc-target{scroll-margin-top:20px}
    .md-search-panel{padding:0 8px 10px;border-bottom:1px solid #8884}
    .md-search-panel input{box-sizing:border-box;width:100%;font:inherit;color:var(--md-ink);background:var(--md-panel);border:1px solid #8887;border-radius:5px;padding:7px;margin-bottom:6px}
    .md-search-actions{display:flex;align-items:center;gap:4px}
    .md-search-count{margin-right:auto;font-variant-numeric:tabular-nums;white-space:nowrap}
    .md-search-actions button{padding:4px 6px;font-size:12px}
    ::highlight(md-search-all){background:#f5d76e;color:#161b22}
    ::highlight(md-search-current){background:#ff832b;color:#161b22}
    @media(max-width:899px){.md-mermaid-hint{width:100%;margin-left:0}}
    @media print{.md-mermaid-placeholder{display:none}.md-mermaid-expanded{position:static;display:block}.md-toc,.md-mermaid-toolbar{display:none!important}.md-mermaid-viewport{height:auto!important;max-height:none;overflow:visible}.md-mermaid-stage{width:auto!important;height:auto!important}.md-mermaid svg{width:100%!important;height:auto!important}}
  `;
  document.head.appendChild(style);
  mermaid.initialize({
    startOnLoad: false,
    securityLevel: 'strict',
    suppressErrorRendering: true,
    theme: theme,
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif',
    flowchart: { useMaxWidth: false },
    class: { useMaxWidth: false },
    sequence: { useMaxWidth: false }
  });

  function button(label, action, title) {
    const element = document.createElement('button');
    element.type = 'button';
    element.textContent = label;
    element.dataset.action = action;
    element.setAttribute('aria-label', title || label);
    element.title = title || label;
    return element;
  }

  function addDiagramControls(container, index) {
    const svg = container.querySelector('svg');
    if (!svg) return;
    const box = svg.viewBox.baseVal;
    const width = box.width || svg.getBoundingClientRect().width || 600;
    const height = box.height || svg.getBoundingClientRect().height || 400;
    const toolbar = document.createElement('div');
    toolbar.className = 'md-mermaid-toolbar';
    const zoomOut = button('−', 'zoom-out', '缩小图表');
    const zoomIn = button('+', 'zoom-in', '放大图表');
    const fit = button('适应宽度', 'fit');
    const reset = button('重置', 'reset', '恢复 100% 原始大小');
    const fullscreen = button('全屏', 'fullscreen', '铺满文档预览区域');
    fullscreen.setAttribute('aria-pressed', 'false');
    const output = document.createElement('output');
    output.setAttribute('aria-label', '缩放比例');
    output.setAttribute('aria-live', 'polite');
    const hint = document.createElement('span');
    hint.className = 'md-mermaid-hint';
    hint.textContent = '按住鼠标拖动查看';
    toolbar.append(zoomOut, output, zoomIn, fit, reset, fullscreen, hint);
    const viewport = document.createElement('div');
    viewport.className = 'md-mermaid-viewport';
    viewport.tabIndex = 0;
    viewport.setAttribute('role', 'region');
    viewport.setAttribute('aria-label', '图表 ' + (index + 1) + '，可拖动或使用方向键查看');
    const stage = document.createElement('div');
    stage.className = 'md-mermaid-stage';
    stage.appendChild(svg);
    viewport.appendChild(stage);
    container.append(toolbar, viewport);
    let scale = 1;
    let fitMode = false;
    let pristine = true;
    let expandedState = null;
    function updateHeight() {
      if (expandedState) { viewport.style.height = '0px'; return; }
      viewport.style.height = Math.max(120, Math.min(height * scale + 32, window.innerHeight * 0.65, 640)) + 'px';
    }
    function focusFirstNode() {
      const first = svg.querySelector('g.node, g.classGroup');
      if (!first) return;
      const nodeBounds = first.getBoundingClientRect();
      const frame = viewport.getBoundingClientRect();
      viewport.scrollLeft += nodeBounds.left - frame.left - Math.max(16, (viewport.clientWidth - nodeBounds.width) / 2);
      viewport.scrollTop += nodeBounds.top - frame.top - 16;
    }
    function zoom(next, anchorX, anchorY) {
      const x = anchorX === undefined ? viewport.clientWidth / 2 : anchorX;
      const y = anchorY === undefined ? viewport.clientHeight / 2 : anchorY;
      const contentX = (viewport.scrollLeft + x - 16) / scale;
      const contentY = (viewport.scrollTop + y - 16) / scale;
      scale = Math.max(0.1, Math.min(4, next));
      svg.style.width = width * scale + 'px';
      svg.style.height = height * scale + 'px';
      stage.style.width = width * scale + 'px';
      stage.style.height = height * scale + 'px';
      updateHeight();
      viewport.scrollLeft = contentX * scale + 16 - x;
      viewport.scrollTop = contentY * scale + 16 - y;
      output.textContent = Math.round(scale * 100) + '%';
    }
    function fitWidth() {
      zoom(Math.min(1, Math.max(0.1, (viewport.clientWidth - 32) / width)));
      viewport.scrollLeft = 0;
      viewport.scrollTop = 0;
    }
    zoomIn.addEventListener('click', function () { pristine = false; fitMode = false; zoom(scale * 1.2); });
    zoomOut.addEventListener('click', function () { pristine = false; fitMode = false; zoom(scale / 1.2); });
    fit.addEventListener('click', function () { pristine = false; fitMode = true; fitWidth(); });
    reset.addEventListener('click', function () {
      pristine = true; fitMode = false; zoom(1); viewport.scrollLeft = 0; viewport.scrollTop = 0; focusFirstNode();
    });
    function leaveExpandedView() {
      if (!expandedState) return;
      const saved = expandedState;
      expandedState = null;
      activeExpandedDiagram = null;
      container.classList.remove('md-mermaid-expanded');
      container.removeAttribute('role');
      container.removeAttribute('aria-modal');
      container.removeAttribute('aria-label');
      document.documentElement.classList.remove('md-diagram-expanded');
      fitMode = saved.fitMode;
      pristine = saved.pristine;
      zoom(saved.scale, 16, 16);
      saved.placeholder.remove();
      viewport.scrollLeft = saved.left;
      viewport.scrollTop = saved.top;
      window.scrollTo(saved.pageX, saved.pageY);
      fullscreen.textContent = '全屏';
      fullscreen.title = '铺满文档预览区域';
      fullscreen.setAttribute('aria-label', fullscreen.title);
      fullscreen.setAttribute('aria-pressed', 'false');
      hint.textContent = '按住鼠标拖动查看';
      if (saved.focus && saved.focus.isConnected) saved.focus.focus({ preventScroll: true });
    }
    fullscreen.addEventListener('click', function () {
      if (expandedState) { leaveExpandedView(); return; }
      if (activeExpandedDiagram) activeExpandedDiagram();
      // Keep the document footprint so closing the overlay returns to the same place.
      const placeholder = document.createElement('div');
      placeholder.className = 'md-mermaid-placeholder';
      placeholder.setAttribute('aria-hidden', 'true');
      placeholder.style.height = container.getBoundingClientRect().height + 'px';
      placeholder.style.margin = '16px 0';
      expandedState = {
        scale: scale, fitMode: fitMode, pristine: pristine,
        left: viewport.scrollLeft, top: viewport.scrollTop,
        pageX: window.scrollX, pageY: window.scrollY,
        focus: document.activeElement, placeholder: placeholder
      };
      container.before(placeholder);
      activeExpandedDiagram = leaveExpandedView;
      container.classList.add('md-mermaid-expanded');
      container.setAttribute('role', 'dialog');
      container.setAttribute('aria-modal', 'true');
      container.setAttribute('aria-label', '图表全屏查看');
      document.documentElement.classList.add('md-diagram-expanded');
      fullscreen.textContent = '退出全屏';
      fullscreen.title = '恢复文档内查看（Esc）';
      fullscreen.setAttribute('aria-label', fullscreen.title);
      fullscreen.setAttribute('aria-pressed', 'true');
      hint.textContent = '拖动查看 · Ctrl/⌘ + 滚轮缩放';
      resize();
      fullscreen.focus({ preventScroll: true });
    });
    document.addEventListener('keydown', function (event) {
      if (!expandedState) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        leaveExpandedView();
      } else if (event.key === 'Tab') {
        const targets = Array.from(container.querySelectorAll('button,[href],[tabindex]')).filter(function (target) {
          return !target.disabled && target.tabIndex >= 0 && target.getClientRects().length > 0;
        });
        const first = targets[0];
        const last = targets[targets.length - 1];
        if (event.shiftKey && (document.activeElement === first || !container.contains(document.activeElement))) {
          event.preventDefault(); last.focus();
        } else if (!event.shiftKey && (document.activeElement === last || !container.contains(document.activeElement))) {
          event.preventDefault(); first.focus();
        }
      }
    }, true);
    viewport.addEventListener('wheel', function (event) {
      if (!expandedState) {
        // Inline diagrams leave wheel navigation to the document, including at their edges.
        event.preventDefault();
        if (!event.ctrlKey && !event.metaKey) {
          const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? window.innerHeight : 1;
          window.scrollBy(event.deltaX * unit, event.deltaY * unit);
        }
        return;
      }
      if (!event.ctrlKey && !event.metaKey) return;
      event.preventDefault();
      pristine = false;
      fitMode = false;
      const bounds = viewport.getBoundingClientRect();
      zoom(scale * Math.exp(-event.deltaY * 0.002), event.clientX - bounds.left, event.clientY - bounds.top);
    }, { passive: false });
    let drag = null;
    viewport.addEventListener('mousedown', function (event) {
      if (event.button !== 0 || event.target.closest('a,button')) return;
      // Leave native scroll bars usable instead of treating them as a drag handle.
      const bounds = viewport.getBoundingClientRect();
      if (event.clientX - bounds.left >= viewport.clientWidth || event.clientY - bounds.top >= viewport.clientHeight) return;
      event.preventDefault();
      pristine = false;
      drag = { x: event.clientX, y: event.clientY, left: viewport.scrollLeft, top: viewport.scrollTop };
      viewport.classList.add('md-dragging');
    });
    document.addEventListener('mousemove', function (event) {
      if (!drag) return;
      viewport.scrollLeft = drag.left + drag.x - event.clientX;
      viewport.scrollTop = drag.top + drag.y - event.clientY;
    });
    function stopDrag() { drag = null; viewport.classList.remove('md-dragging'); }
    document.addEventListener('mouseup', stopDrag);
    window.addEventListener('blur', stopDrag);
    function resize() {
      updateHeight();
      if (fitMode) fitWidth();
      else if (pristine) focusFirstNode();
    }
    if (typeof ResizeObserver === 'function') new ResizeObserver(resize).observe(viewport);
    window.addEventListener('resize', resize);
    zoom(1, 16, 16);
    viewport.scrollLeft = 0;
    viewport.scrollTop = 0;
    focusFirstNode();
  }

  function installNavigation() {
    const headings = Array.from(document.querySelectorAll('body h1,body h2,body h3,body h4,body h5,body h6'));
    const nav = document.createElement('nav');
    nav.className = 'md-toc';
    nav.setAttribute('aria-label', '文档目录与搜索');
    const header = document.createElement('div');
    header.className = 'md-toc-header';
    const toggle = button('目录 TOC · 展开', 'toc-toggle');
    toggle.className = 'md-toc-toggle';
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-controls', 'md-preview-toc-list');
    const searchToggle = button('搜索', 'search-toggle');
    searchToggle.className = 'md-search-toggle';
    searchToggle.setAttribute('aria-expanded', 'false');
    header.append(toggle, searchToggle);
    const list = document.createElement('ol');
    list.id = 'md-preview-toc-list';
    list.className = 'md-toc-list';
    list.hidden = true;
    const links = [];
    headings.forEach(function (heading, index) {
      let id = heading.id;
      if (!id || document.getElementById(id) !== heading) {
        id = 'md-preview-heading-' + index;
        while (document.getElementById(id)) id += '-';
        heading.id = id;
      }
      heading.classList.add('md-toc-target');
      const item = document.createElement('li');
      const link = document.createElement('a');
      link.setAttribute('href', '#' + id);
      link.textContent = heading.textContent.trim();
      link.style.paddingLeft = 8 + Math.min(4, Number(heading.tagName.slice(1)) - 1) * 12 + 'px';
      link.addEventListener('click', function (event) {
        event.preventDefault();
        heading.scrollIntoView({ block: 'start' });
      });
      item.appendChild(link);
      list.appendChild(item);
      links.push(link);
    });
    const panel = document.createElement('div');
    panel.className = 'md-search-panel';
    panel.hidden = true;
    const input = document.createElement('input');
    input.type = 'search';
    input.placeholder = '搜索正文与图表文字';
    input.setAttribute('aria-label', '搜索预览内容');
    const actions = document.createElement('div');
    actions.className = 'md-search-actions';
    const count = document.createElement('span');
    count.className = 'md-search-count';
    count.setAttribute('aria-live', 'polite');
    count.textContent = '0 / 0';
    const previous = button('上一处', 'search-previous');
    const next = button('下一处', 'search-next');
    const close = button('关闭', 'search-close');
    actions.append(count, previous, next, close);
    panel.append(input, actions);
    nav.append(header, panel, list);
    document.body.prepend(nav);
    function updatePanelLayout() {
      const open = !list.hidden || !panel.hidden;
      nav.classList.toggle('compact', !open);
      document.documentElement.classList.toggle('md-toc-open', !list.hidden);
    }
    toggle.addEventListener('click', function () {
      list.hidden = !list.hidden;
      toggle.setAttribute('aria-expanded', String(!list.hidden));
      toggle.textContent = list.hidden ? '目录 TOC · 展开' : '目录 TOC · 收起';
      updatePanelLayout();
    });
    const canHighlight = Boolean(window.CSS && CSS.highlights && typeof Highlight === 'function');
    let matches = [];
    let current = -1;
    function clearHighlights() {
      if (canHighlight) { CSS.highlights.delete('md-search-all'); CSS.highlights.delete('md-search-current'); }
    }
    function showMatch(index, scroll) {
      current = matches.length ? (index + matches.length) % matches.length : -1;
      count.textContent = (current + 1) + ' / ' + matches.length;
      previous.disabled = next.disabled = matches.length === 0;
      if (current < 0) return;
      const range = matches[current];
      if (canHighlight) CSS.highlights.set('md-search-current', new Highlight(range));
      else {
        const selection = window.getSelection();
        selection.removeAllRanges(); selection.addRange(range);
      }
      if (scroll) range.startContainer.parentElement.scrollIntoView({ block: 'center' });
    }
    function search() {
      clearHighlights();
      matches = [];
      const query = input.value;
      if (!query || panel.hidden) { showMatch(-1, false); return; }
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const segments = [];
      let text = '';
      let node;
      while ((node = walker.nextNode())) {
        if (node.parentElement.closest('script,style,.md-toc,.md-mermaid-toolbar,svg title,svg desc')) continue;
        const start = text.length;
        text += node.nodeValue;
        if (text.length > start) segments.push({ node: node, start: start, end: text.length });
      }
      function locate(offset, end) {
        let low = 0;
        let high = segments.length - 1;
        while (low < high) {
          const middle = (low + high) >> 1;
          if (end ? segments[middle].end >= offset : segments[middle].end > offset) high = middle;
          else low = middle + 1;
        }
        return segments[low];
      }
      const expression = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'giu');
      let match;
      while ((match = expression.exec(text)) && matches.length < 2000) {
        const start = locate(match.index, false);
        const end = locate(match.index + match[0].length, true);
        const range = document.createRange();
        range.setStart(start.node, match.index - start.start);
        range.setEnd(end.node, match.index + match[0].length - end.start);
        matches.push(range);
      }
      if (canHighlight && matches.length) CSS.highlights.set('md-search-all', new Highlight(...matches));
      showMatch(0, matches.length > 0);
    }
    function openSearch(open) {
      if (open && activeExpandedDiagram) activeExpandedDiagram();
      panel.hidden = !open;
      searchToggle.setAttribute('aria-expanded', String(open));
      updatePanelLayout();
      if (open) { input.focus(); input.select(); search(); }
      else { clearHighlights(); searchToggle.focus(); }
    }
    searchToggle.addEventListener('click', function () { openSearch(panel.hidden); });
    close.addEventListener('click', function () { openSearch(false); });
    input.addEventListener('input', search);
    previous.addEventListener('click', function () { showMatch(current - 1, true); });
    next.addEventListener('click', function () { showMatch(current + 1, true); });
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') { event.preventDefault(); showMatch(current + (event.shiftKey ? -1 : 1), true); }
      if (event.key === 'Escape') { event.preventDefault(); openSearch(false); }
    });
    document.addEventListener('keydown', function (event) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'f') { event.preventDefault(); openSearch(true); }
    });
    let scheduled = false;
    function updateActive() {
      scheduled = false;
      let active = 0;
      headings.forEach(function (heading, index) { if (heading.getBoundingClientRect().top <= 80) active = index; });
      links.forEach(function (link, index) {
        link.classList.toggle('is-current', index === active);
        if (index === active) link.setAttribute('aria-current', 'location');
        else link.removeAttribute('aria-current');
      });
    }
    window.addEventListener('scroll', function () {
      if (!scheduled) { scheduled = true; requestAnimationFrame(updateActive); }
    }, { passive: true });
    updatePanelLayout();
    updateActive();
    return function () { updateActive(); if (!panel.hidden) search(); };
  }

  async function renderDiagrams() {
    const refreshNavigation = installNavigation();
    if (document.fonts && document.fonts.ready) await document.fonts.ready;
    const blocks = Array.from(document.querySelectorAll('pre > code.language-mermaid'));
    for (let index = 0; index < blocks.length; index += 1) {
      const code = blocks[index];
      const source = code.textContent;
      const pre = code.parentElement;
      const container = document.createElement('div');
      container.className = 'md-mermaid';
      try {
        const result = await mermaid.render('mdmermaid' + index, source);
        container.innerHTML = result.svg;
        pre.replaceWith(container);
        addDiagramControls(container, index);
        if (result.bindFunctions) result.bindFunctions(container);
      } catch (error) {
        const message = document.createElement('div');
        message.className = 'md-mermaid-error';
        message.textContent = 'Mermaid 图表暂无法显示，请检查语法。' + (error && error.message ? '\n' + error.message : '');
        pre.before(message);
      }
    }
    refreshNavigation();
    document.documentElement.dataset.mermaidReady = 'true';
  }
  function start() {
    renderDiagrams().catch(function (error) {
      console.error('Markdown Editor Mermaid:', error);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
}());
