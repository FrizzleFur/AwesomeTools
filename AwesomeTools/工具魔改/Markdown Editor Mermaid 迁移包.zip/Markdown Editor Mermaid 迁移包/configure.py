# 创建者：mike
"""Install or restore Mermaid through Markdown Editor's user preview themes."""
import json
import pathlib
import plistlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
DOMAIN = pathlib.Path('/Users/mac/Library/Containers/info.iwaki.MarkdownEditor/Data/Library/Preferences/info.iwaki.MarkdownEditor')
PREFERENCES = DOMAIN.with_suffix('.plist')
BACKUP = ROOT / 'backup' / 'preferences-before-mermaid.plist'
MARKER = '// Markdown Editor Mermaid extension 12.2.0\n'


def clear_cfprefsd_cache():
    """defaults import 绕过 cfprefsd 直接写文件，域缓存会继续向应用返回旧值（2026-10-29 本机实测）。
    清掉该域的磁盘缓存并重启偏好守护，应用下次启动才会读到刚写入的设置。"""
    cache_root = subprocess.run(['getconf', 'DARWIN_USER_CACHE_DIR'], capture_output=True, text=True).stdout.strip()
    if cache_root:
        domain_cache = pathlib.Path(cache_root) / 'info.iwaki.MarkdownEditor'
        if domain_cache.exists():
            import shutil
            shutil.rmtree(domain_cache, ignore_errors=True)
    subprocess.run(['killall', 'cfprefsd'], capture_output=False, check=False)


def main():
    if subprocess.run(['pgrep', '-x', 'Markdown Editor'], capture_output=True, check=False).returncode == 0:
        raise SystemExit('请先退出 Markdown Editor，避免设置缓存覆盖。')
    current = plistlib.loads(PREFERENCES.read_bytes()) if PREFERENCES.exists() else {}
    if not BACKUP.exists():
        BACKUP.parent.mkdir(parents=True, exist_ok=True)
        BACKUP.write_bytes(plistlib.dumps(current))
    if len(sys.argv) > 1 and sys.argv[1] == 'restore':
        original = plistlib.loads(BACKUP.read_bytes())
        if 'PreviewThemes' in original:
            current['PreviewThemes'] = original['PreviewThemes']
        else:
            current.pop('PreviewThemes', None)
    else:
        if 'PreviewThemes' in current:
            themes = json.loads(current['PreviewThemes'])
        else:
            themes = [json.loads((pathlib.Path('/Applications/Markdown Editor.app/Contents/Resources/PreviewThemes') / theme / 'Theme.json').read_text()) for theme in ['Dark', 'Light']]
        library = (ROOT / 'mermaid.min.js').read_text()
        bridge = (ROOT / 'preview-mermaid.js').read_text()
        for theme in themes:
            custom = theme.setdefault('customBodyElements', [])
            custom[:] = [element for element in custom if not element.get('content', '').startswith(MARKER)]
            elements = theme.setdefault('bodyElements', [])
            elements[:] = [element for element in elements if not element.get('content', '').startswith(MARKER)]
            mode = 'dark' if theme.get('appearance') == 'dark' else 'default'
            content = MARKER + library + '\nwindow.markdownEditorMermaidTheme=' + json.dumps(mode) + ';\n' + bridge
            if '</script' in content.lower():
                raise SystemExit('脚本包含意外的 HTML script 结束标签，已停止安装。')
            elements.append({'type': 'text/javascript', 'content': content})
        current['PreviewThemes'] = json.dumps(themes, ensure_ascii=False).encode()
    staged = ROOT / 'settings-import.plist'
    staged.write_bytes(plistlib.dumps(current, fmt=plistlib.FMT_BINARY))
    subprocess.run(['defaults', 'import', str(DOMAIN), str(staged)], check=True)
    clear_cfprefsd_cache()
    exported = ROOT / 'settings-verified.plist'
    subprocess.run(['defaults', 'export', str(DOMAIN), str(exported)], check=True, capture_output=True)
    actual = plistlib.loads(exported.read_bytes())
    assert actual.get('PreviewThemes') == current.get('PreviewThemes'), '设置写入核对失败'
    print('已恢复原预览主题。' if len(sys.argv) > 1 and sys.argv[1] == 'restore' else 'Mermaid 预览扩展已写入，字节数：' + str(len(current['PreviewThemes'])))


if __name__ == '__main__':
    main()
